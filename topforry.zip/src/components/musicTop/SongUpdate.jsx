export default function SongUpdate() {
    return (
     
            <h2 className="title">Modificar Cancion</h2>
            
            
        
    
    );
}