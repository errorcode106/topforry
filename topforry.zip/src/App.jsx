import { Routes, Route } from "react-router-dom"
import Inicio from "./components/Inicio"
import SobreNosotros from "./components/SobreNosotros"
import Contacto from "./components/Contacto"




