export default function Profile() {
    return (
        <div className="box content has-text-centered is-medium my-6">
            <h2 className="title">Top Profile...</h2>
            <p>
                Tu perfil, si logeaste correctamente,
                <h2>Desbloqueaste el perfil xD</h2>
            </p>
            
        
        </div>
    );
}