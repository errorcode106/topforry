import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Navbar = ({ logoSrc, logoAlt, navItems, buttonLinks, onLogout }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    // Verifica si hay un authToken en localStorage para determinar el estado de sesión
    const token = localStorage.getItem('authToken');
    setIsLoggedIn(!!token);
  }, []);

  const handleLogin = () => {
    window.location.href = '/login'; // Redirige a la página de inicio de sesión
  };

  const handleLogout = async () => {
    const token = localStorage.getItem('authToken');
    //const csrfToken = document.cookie.split('; ').find(row => row.startsWith('csrftoken=')).split('=')[1]; // Obtener CSRF token si es necesario

    if (!token) {
      console.error('No se encontró el authToken');
      return;
    }

    try {
      const response = await fetch('https://sandbox.academiadevelopers.com/users/profiles/logout/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Token ${token}`, // Enviar el token en el encabezado de autorización
          
        },
      });

      if (response.ok) {
        localStorage.removeItem('authToken'); // Elimina el authToken de localStorage
        setIsLoggedIn(false); // Actualiza el estado de autenticación
        onLogout(); // Ejecuta la función onLogout
      } else {
        console.error('Error al cerrar sesión:', response.statusText);
      }
    } catch (error) {
      console.error('Error al cerrar sesión:', error);
    }
  };

  return (
    <nav className="navbar navbar-expand-lg">
      <div className="container-fluid">
        <a className="navbar-brand" href="#">
          <img src={logoSrc} alt={logoAlt} height="32" />
        </a>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarScroll"
          aria-controls="navbarScroll"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarScroll">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            {navItems.map((item, index) => (
              item.requiresAuth && !isLoggedIn ? null : (
                item.dropdown ? (
                  <li key={index} className="nav-item dropdown">
                    <a
                      className="nav-link dropdown-toggle text-light"
                      href="#"
                      id={`navbarDropdown${index}`}
                      role="button"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                    >
                      {item.text}
                    </a>
                    <ul className="dropdown-menu" aria-labelledby={`navbarDropdown${index}`}>
                      {item.dropdownItems.map((dropdownItem, idx) => (
                        <li key={idx}>
                          <a className="dropdown-item" href={dropdownItem.href}>{dropdownItem.text}</a>
                        </li>
                      ))}
                    </ul>
                  </li>
                ) : (
                  <li key={index} className="nav-item">
                    <a className="nav-link text-light" href={item.href}>{item.text}</a>
                  </li>
                )
              )
            ))}
          </ul>
          <ul className="navbar-nav">
            {buttonLinks.map((button, index) => (
              button.requiresAuth && !isLoggedIn ? null : (
                <li key={index} className="nav-item">
                  <a
                    className={`btn ${button.className} me-2`}
                    href={button.href}
                    onClick={button.onClick}
                  >
                    {button.text}
                  </a>
                </li>
              )
            ))}
            <li className="nav-item">
              <a
                className="btn btn-danger"
                href="#"
                onClick={isLoggedIn ? handleLogout : handleLogin}
              >
                {isLoggedIn ? "Cerrar Sesión" : "Iniciar Sesión"}
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
