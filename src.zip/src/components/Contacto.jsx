import React from 'react'

function Contacto() {
    return (
        <div>
            <h1>Esta es la página de contacto</h1>
        </div>
    )
}

export default Contacto